# Sidhant Ghuge — Portfolio

Personal portfolio for a Quality Engineering & DevSecOps leader, designed as an engineer's notebook:
graph paper, handwritten notes, highlighter, tape and sticky notes. Light mode is paper, dark mode is blueprint.

## Tech stack

| Layer | Choice | Why |
|---|---|---|
| UI library | **React 19** | Component model; the most widely used front-end library |
| Language | **TypeScript** | Typed content model (`src/data/resume.ts`) catches mistakes at build time |
| Build tool | **Vite** | Instant dev server, fast optimised production builds |
| Styling | **Tailwind CSS v4** | Utility classes driven by CSS-variable design tokens; light & dark themes |
| Animation | **Motion** (formerly Framer Motion) | Pipeline run animation and tab transitions; respects reduced-motion |
| Icons | **lucide-react** | Tree-shaken SVG icons |
| Fonts | Young Serif, Karla, Courier Prime, Nanum Pen Script | Self-hosted via Fontsource (no third-party requests) |
| Hosting | Static — Vercel, Netlify or GitHub Pages | No server needed |

## Structure

```
src/
  data/resume.ts        ← ALL content lives here. Edit this to update the site.
  components/           ← One component per section (Hero, Pipeline, Experience, …)
  index.css             ← Design tokens (colors, fonts) + Tailwind setup
  App.tsx               ← Page composition
```

## Run locally

```bash
npm install
npm run dev          # http://localhost:5173
npm run build        # production build → dist/
npm run build:single # one self-contained HTML file → dist-single/index.html
```

## Add your photo

Put an image at `public/me.jpg`, then in `src/data/resume.ts` set `photo: "me.jpg"`.

## Deploy to GitHub Pages

First, pick where it lives. This decides the URL:

| Option | Repo name | URL |
|---|---|---|
| **A. User site** (recommended) | `<your-username>.github.io` | `https://<your-username>.github.io` |
| **B. Project site** | anything, e.g. `portfolio` | `https://<your-username>.github.io/portfolio/` |
| **C. Custom domain** | either of the above | e.g. `https://sidhantghuge.com` |

### Method 1 — GitHub Actions (recommended, already set up)

1. Create the repo on GitHub and push this folder to the `main` branch:
   ```bash
   git init && git add . && git commit -m "Portfolio"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
2. In the repo: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Open the **Actions** tab and wait for "Deploy to GitHub Pages" to finish (about a minute).
   Every later push to `main` redeploys automatically.

The workflow (`.github/workflows/deploy.yml`) detects whether this is a user site, project
site or custom domain and sets the base path for you.

### Method 2 — `gh-pages` branch from your laptop

```bash
# User site (A) or custom domain (C):
npm run deploy
# Project site (B) — the base path must match the repo name:
BASE_PATH=/<repo-name>/ npm run deploy
```
Then **Settings → Pages → Source: Deploy from a branch → `gh-pages` / root**.

### Custom domain (option C)

1. Buy a domain (Namecheap, GoDaddy, Cloudflare, Squarespace, etc.).
2. **Settings → Pages → Custom domain** → enter it → Save, and tick **Enforce HTTPS**.
3. At your domain registrar add DNS records:
   - apex (`sidhantghuge.com`): four `A` records → `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - `www`: a `CNAME` record → `<your-username>.github.io`
