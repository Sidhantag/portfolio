import { Nav } from "./components/Nav";
import { Hero } from "./components/Hero";
import { Experience } from "./components/Experience";
import { CaseStudies } from "./components/CaseStudies";
import { HowIWork } from "./components/HowIWork";
import { SecurityArchitecture } from "./components/SecurityArchitecture";
import { Projects } from "./components/Projects";
import { Skills } from "./components/Skills";
import { Credentials } from "./components/Credentials";
import { Contact } from "./components/Contact";

export default function App() {
  return (
    <>
      <Nav />
      {/* overflow-x-clip keeps rotated sheets from causing sideways scroll */}
      <main className="relative mx-auto max-w-6xl overflow-x-clip px-4 sm:px-6">
        <Hero />
        <Experience />
        <CaseStudies />
        <HowIWork />
        <SecurityArchitecture />
        <Projects />
        <Skills />
        <Credentials />
        <Contact />
      </main>
    </>
  );
}
