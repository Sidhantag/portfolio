import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { caseStudies } from "../data/resume";
import { Section } from "./Section";

// Index-tab colours (like coloured file dividers)
const tabColors = ["#f6d860", "#f4a7b9", "#9fd0f5", "#a9dc8f", "#f7bd7f", "#c9b6f2", "#8fd6cf"];

export function CaseStudies() {
  const [activeId, setActiveId] = useState(caseStudies[0].id);
  const idx = caseStudies.findIndex((c) => c.id === activeId);
  const cs = caseStudies[idx];

  return (
    <Section
      id="impact"
      label="Impact · case files"
      title="The stories behind the numbers"
      intro="Each headline result from my résumé, with the context, what I did and the tools involved."
      note="pick a tab ↓"
    >
      <div role="tablist" aria-label="Case studies" className="no-scrollbar -mx-4 flex items-end gap-1 overflow-x-auto px-4 sm:mx-0 sm:px-0">
        {caseStudies.map((c, i) => {
          const on = c.id === activeId;
          return (
            <button
              key={c.id}
              role="tab"
              id={`tab-${c.id}`}
              aria-selected={on}
              aria-controls="case-panel"
              onClick={() => setActiveId(c.id)}
              className={`shrink-0 rounded-t-lg px-4 font-type text-sm font-bold text-[#25282c] transition-all ${on ? "pt-3 pb-2.5" : "pt-2 pb-1.5 opacity-75 hover:opacity-100"}`}
              style={{ background: tabColors[i % tabColors.length] }}
            >
              {c.label}
            </button>
          );
        })}
      </div>

      <div
        id="case-panel"
        role="tabpanel"
        aria-labelledby={`tab-${cs.id}`}
        className="sheet overflow-hidden border-t-[6px]"
        style={{ borderTopColor: tabColors[idx % tabColors.length] }}
      >
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={cs.id}
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -12 }}
            transition={{ duration: 0.18 }}
            className="grid lg:grid-cols-[1.5fr_1fr]"
          >
            <div className="p-6 sm:p-10">
              <h3 className="text-3xl sm:text-4xl">{cs.title}</h3>
              <p className="mt-4 font-serif text-xl"><span className="hl">{cs.result}</span></p>

              <p className="type-label mt-9 mb-2">The situation</p>
              <p className="max-w-prose text-ink-2">{cs.context}</p>

              <p className="type-label mt-9 mb-3">What I did</p>
              <ol className="space-y-4">
                {cs.approach.map((a, i) => (
                  <li key={a} className="flex gap-4 text-ink-2">
                    <span className="hand w-6 shrink-0 text-center !text-3xl">{i + 1}.</span>
                    <span>{a}</span>
                  </li>
                ))}
              </ol>
            </div>
            <aside className="border-t-2 border-dashed border-ink/15 p-6 sm:p-10 lg:border-t-0 lg:border-l-2">
              <p className="type-label mb-4">Result</p>
              <ul className="space-y-3">
                {cs.outcome.map((o) => (
                  <li key={o} className="flex gap-3 font-bold">
                    <span className="hand shrink-0 !text-2xl">✓</span>
                    <span>{o}</span>
                  </li>
                ))}
              </ul>
              <p className="type-label mt-10 mb-3">Tools</p>
              <div className="flex flex-wrap gap-2">
                {cs.stack.map((s) => (
                  <span key={s} className="sketch-dashed px-2.5 py-1 font-type text-xs text-ink-2">{s}</span>
                ))}
              </div>
            </aside>
          </motion.div>
        </AnimatePresence>
      </div>
    </Section>
  );
}
