import { useEffect, useState } from "react";
import { useReducedMotion } from "motion/react";
import { RotateCcw } from "lucide-react";
import { Tick } from "./Doodles";

// A release checklist on an index card, ticked off stage by stage.
const stages = [
  { name: "Checkout", tool: "Bitbucket" },
  { name: "Build", tool: "Jenkins / Azure DevOps" },
  { name: "SAST scan", tool: "Fortify ScanCentral" },
  { name: "SCA scan", tool: "Nexus IQ + Black Duck" },
  { name: "Regression", tool: "1,200+ Playwright tests" },
  { name: "DAST scan", tool: "WebInspect" },
  { name: "Release gate", tool: "policy + SLO baseline" },
];

export function Checklist() {
  const reduce = useReducedMotion();
  const [step, setStep] = useState(reduce ? stages.length : 0);
  const [run, setRun] = useState(0);

  useEffect(() => {
    if (reduce) { setStep(stages.length); return; }
    setStep(0);
    const id = setInterval(() => {
      setStep((s) => {
        if (s >= stages.length) { clearInterval(id); return s; }
        return s + 1;
      });
    }, 380);
    return () => clearInterval(id);
  }, [run, reduce]);

  const done = step >= stages.length;

  return (
    <div className="lined sheet tape rotate-[-1.2deg] pt-8 pb-4 pr-4 pl-14">
      <div className="flex h-8 items-baseline justify-between gap-3">
        <p className="font-type text-sm font-bold uppercase tracking-wide">Release checklist</p>
        <p className="tnum font-type text-xs text-ink-3">build #{2417 + run}</p>
      </div>
      <ul>
        {stages.map((s, i) => {
          const ticked = i < step;
          return (
            <li key={s.name} className="relative flex h-8 items-center justify-between gap-3">
              <span className="absolute -left-10 grid size-6 place-items-center">
                <span className="absolute inset-0.5 rounded-[3px] border-[1.5px] border-ink-3" />
                {ticked && <Tick className="relative size-6 -translate-y-0.5 translate-x-0.5 text-pen" />}
              </span>
              <span className={`shrink-0 text-[15px] ${ticked ? "text-ink" : "text-ink-3"}`}>{s.name}</span>
              <span className="truncate font-type text-xs text-ink-3">{s.tool}</span>
            </li>
          );
        })}
      </ul>
      <div className="flex min-h-10 flex-wrap items-center justify-between gap-x-3 pt-1">
        <span className={`hand !text-2xl transition-opacity ${done ? "opacity-100" : "opacity-0"}`}>
          all clear, 0 criticals. ship it!
        </span>
        <button
          onClick={() => setRun((r) => r + 1)}
          className="inline-flex shrink-0 items-center gap-1.5 px-2 py-1 font-type text-xs text-ink-3 hover:text-ink"
        >
          <RotateCcw size={12} /> run again
        </button>
      </div>
    </div>
  );
}
