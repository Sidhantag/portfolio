import { useState } from "react";
import { profile } from "../data/resume";

export function Contact() {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(profile.email);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      const el = document.getElementById("email-text");
      if (el) window.getSelection()?.selectAllChildren(el);
    }
  };

  return (
    <section id="contact" className="py-16 sm:py-24">
      <p className="type-label mb-6">Contact</p>
      {/* A postcard */}
      <div className="sheet rotate-[-0.8deg] p-6 sm:p-10">
        <div className="grid gap-10 md:grid-cols-[1.2fr_1fr]">
          <div className="md:border-r-2 md:border-dashed md:border-ink/20 md:pr-10">
            <h2 className="text-4xl sm:text-5xl">Let's talk.</h2>
            <p className="mt-6 text-ink-2">
              I'm looking for my next role in QA leadership, SDET, DevSecOps or AI quality. If your team needs someone to own
              quality, security and reliability, I'd like to hear about it.
            </p>
            <p className="hand mt-6">— Sidhant</p>
          </div>
          <div className="relative">
            <div className="absolute top-0 right-0 grid h-20 w-16 rotate-3 place-items-center border-2 border-dashed border-red p-1 text-center font-type text-[10px] leading-tight font-bold text-red uppercase">
              Pune<br />MH<br />411
            </div>
            <div className="space-y-6 pt-24 md:pt-16">
              <div className="border-b-2 border-ink/20 pb-2">
                <p className="type-label mb-1">Email</p>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span id="email-text" className="font-type select-all">{profile.email}</span>
                  <button onClick={copy} className="font-type text-sm font-bold text-pen underline underline-offset-4">
                    {copied ? "copied ✓" : "copy"}
                  </button>
                </div>
              </div>
              <div className="border-b-2 border-ink/20 pb-2">
                <p className="type-label mb-1">LinkedIn</p>
                <a href={profile.linkedin} target="_blank" rel="noreferrer" className="font-type break-all hover:text-pen">
                  {profile.linkedinLabel} ↗
                </a>
              </div>
              <div className="border-b-2 border-ink/20 pb-2">
                <p className="type-label mb-1">Based in</p>
                <span className="font-type">{profile.location}, India</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer className="mt-14 flex flex-col justify-between gap-2 font-type text-xs text-ink-3 sm:flex-row">
        <p>© {new Date().getFullYear()} {profile.fullName}</p>
        <p>Hand-built with React, TypeScript, Vite, Tailwind CSS and Motion.</p>
      </footer>
    </section>
  );
}
