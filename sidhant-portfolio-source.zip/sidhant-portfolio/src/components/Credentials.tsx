import { certifications, education } from "../data/resume";
import { Section } from "./Section";

export function Credentials() {
  return (
    <Section id="credentials" label="Credentials" title="Certifications & education">
      <div className="grid items-start gap-12 lg:grid-cols-[1.5fr_1fr]">
        <ul className="sheet p-6 font-type text-[15px] sm:p-8">
          {certifications.map((c) => (
            <li key={c.name} className="flex items-baseline gap-2 py-2">
              <span className="shrink">
                {c.name} <span className="text-ink-3">· {c.issuer}</span>
              </span>
              <span className="min-w-6 flex-1 translate-y-[-4px] border-b-2 border-dotted border-ink/25" />
              <span className="tnum shrink-0">{c.year}</span>
            </li>
          ))}
        </ul>
        <div className="sheet tape rotate-[1.5deg] p-6 sm:p-8">
          <p className="type-label">Education · {education.year}</p>
          <p className="mt-3 font-serif text-2xl">{education.degree}</p>
          <p className="mt-3 text-ink-2">{education.school}</p>
          <p className="mt-1 text-ink-3">{education.university}</p>
        </div>
      </div>
    </Section>
  );
}
