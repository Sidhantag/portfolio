// Hand-drawn SVG marks. Strokes use currentColor so they follow the pen colour.
import { motion, useReducedMotion } from "motion/react";

type P = { className?: string };

export function Squiggle({ className = "" }: P) {
  return (
    <svg viewBox="0 0 220 18" preserveAspectRatio="none" className={className} aria-hidden="true">
      <path d="M3 11 C 30 4, 52 15, 78 9 S 128 4, 152 10 S 196 14, 217 6" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function ArrowCurve({ className = "", flip = false }: P & { flip?: boolean }) {
  return (
    <svg viewBox="0 0 90 60" className={className} style={flip ? { transform: "scaleX(-1)" } : undefined} aria-hidden="true">
      <path d="M6 8 C 22 40, 48 52, 80 44" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M68 34 L 81 44 L 66 52" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ArrowDown({ className = "" }: P) {
  return (
    <svg viewBox="0 0 40 60" className={className} aria-hidden="true">
      <path d="M22 4 C 14 20, 26 34, 19 54" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M10 44 L 19 55 L 28 45" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/** Rough circle drawn around inline content */
export function CircleAround({ className = "" }: P) {
  return (
    <svg viewBox="0 0 200 80" preserveAspectRatio="none" className={className} aria-hidden="true">
      <path d="M40 10 C 90 0, 170 4, 190 30 C 204 52, 150 76, 92 74 C 36 72, 4 60, 8 38 C 12 18, 60 8, 120 10" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
    </svg>
  );
}

/** Pen tick that draws itself */
export function Tick({ className = "", animate = true }: P & { animate?: boolean }) {
  const reduce = useReducedMotion();
  return (
    <svg viewBox="0 0 28 24" className={className} aria-hidden="true">
      <motion.path
        d="M3 13 L 10 20 C 14 12, 19 6, 26 2"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={animate && !reduce ? { pathLength: 0 } : false}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.35, ease: "easeOut" }}
      />
    </svg>
  );
}
