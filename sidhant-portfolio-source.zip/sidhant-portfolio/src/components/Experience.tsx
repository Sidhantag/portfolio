import { experience } from "../data/resume";
import { Section } from "./Section";

export function Experience() {
  return (
    <Section
      id="experience"
      label="Experience · 2017 – 2025"
      title="Eight years at FinIQ"
      intro="Two roles at the same company: first as the automation expert working directly with clients, then as Assistant Vice President owning quality, security and observability for the whole trading platform."
    >
      <div className="space-y-14">
        {experience.map((r, idx) => (
          <article key={r.title} className={`sheet tape p-6 sm:p-10 ${idx % 2 ? "tape-left rotate-[0.4deg]" : "tape-right rotate-[-0.4deg]"}`}>
            <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1">
              <p className="tnum font-type text-sm text-ink-3">{r.period}</p>
              <p className="font-type text-sm text-ink-3">{r.company} · {r.place}</p>
            </div>
            <h3 className="mt-3 text-2xl sm:text-3xl">{r.title}</h3>
            {idx === 0 && <p className="hand mt-2 rotate-[-1.5deg]">↑ moved up in 2021</p>}
            <p className="mt-4 max-w-3xl text-lg">{r.headline}</p>
            <ul className="mt-8 grid gap-x-10 gap-y-5 md:grid-cols-2">
              {r.points.map((p) => (
                <li key={p.text} className="text-[15px] text-ink-2">
                  <span className="mb-1 block font-type text-xs font-bold tracking-wider text-pen uppercase">{p.tag}</span>
                  {p.text}
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </Section>
  );
}
