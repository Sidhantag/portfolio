import { metrics, profile } from "../data/resume";
import { ArrowCurve, ArrowDown, Squiggle } from "./Doodles";
import { Checklist } from "./Checklist";

// Sticky-note colours: physical paper, same in both themes
const notes = [
  { bg: "#fff1a1", r: "-2deg" },
  { bg: "#ffd3dc", r: "1.5deg" },
  { bg: "#cbe7ff", r: "-1deg" },
  { bg: "#d6f2c2", r: "2deg" },
  { bg: "#ffdcb0", r: "-1.8deg" },
];

function Polaroid() {
  const initials = profile.name.split(" ").map((w) => w[0]).join("");
  return (
    <figure className="sheet tape mx-auto w-60 rotate-[3deg] p-3 pb-2 sm:w-64">
      <div className="aspect-[4/5] overflow-hidden bg-ink/5">
        {profile.photo ? (
          <img src={`${import.meta.env.BASE_URL}${profile.photo}`} alt={profile.fullName} className="size-full object-cover" />
        ) : (
          <div
            className="grid size-full place-items-center"
            style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent 0 10px, var(--grid-major) 10px 11px)" }}
          >
            <span className="font-serif text-6xl text-ink-3">{initials}</span>
          </div>
        )}
      </div>
      <figcaption className="hand pt-2 text-center !text-2xl !text-ink-2">that's me · {profile.location.split(",")[0]}</figcaption>
    </figure>
  );
}

export function Hero() {
  return (
    <section id="top" className="pt-12 pb-10 sm:pt-20">
      <div className="grid items-center gap-14 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="type-label mb-6">Portfolio · {profile.location}</p>
          <h1 className="text-6xl sm:text-7xl lg:text-8xl">
            Sidhant{" "}
            <span className="relative inline-block">
              Ghuge
              <Squiggle className="absolute -bottom-2 left-0 h-4 w-full text-red" />
            </span>
          </h1>
          <p className="mt-8 font-serif text-2xl text-ink-2 sm:text-3xl">
            I make releases <span className="hl text-ink">boring</span>, in the best way.
          </p>
          <p className="mt-6 max-w-xl text-ink-2">{profile.summary}</p>

          <div className="relative mt-9 flex flex-wrap items-center gap-4">
            <a href="#impact" className="sketch bg-ink px-5 py-2.5 font-type text-sm font-bold text-paper hover:-rotate-1 transition-transform">
              See the work
            </a>
            <a href={profile.linkedin} target="_blank" rel="noreferrer" className="sketch px-5 py-2.5 font-type text-sm font-bold hover:rotate-1 transition-transform">
              LinkedIn ↗
            </a>
            <a href="#contact" className="font-type text-sm font-bold underline decoration-pen decoration-2 underline-offset-4">
              Get in touch
            </a>
            <span className="hand hidden items-end gap-1 sm:inline-flex">
              <ArrowCurve className="h-9 w-14 -scale-x-100 rotate-180 text-pen" /> open to new roles!
            </span>
          </div>
        </div>
        <Polaroid />
      </div>

      <div className="mt-20 grid items-start gap-12 lg:grid-cols-[1fr_1.25fr]">
        <div>
          <p className="hand mb-5 flex items-end gap-2 -rotate-2">
            what a release looked like on my watch <ArrowDown className="h-10 w-6 text-pen" />
          </p>
          <Checklist />
        </div>
        <div>
          <p className="hand mb-5 -rotate-1">the numbers I'm proud of</p>
          <ul className="grid grid-cols-2 gap-5 sm:grid-cols-3">
            {metrics.map((m, i) => (
              <li
                key={m.label}
                className="sticky p-4 pb-5"
                style={{ background: notes[i % notes.length].bg, transform: `rotate(${notes[i % notes.length].r})` }}
              >
                <p className="tnum font-serif text-3xl leading-none">{m.value}</p>
                <p className="mt-2 text-sm font-bold">{m.label}</p>
                <p className="mt-1 font-type text-xs opacity-70">{m.note}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
