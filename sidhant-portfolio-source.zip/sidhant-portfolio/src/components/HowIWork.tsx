import { approach } from "../data/resume";
import { Section } from "./Section";

export function HowIWork() {
  return (
    <Section id="approach" label="Approach" title="How I work" intro={approach.intro}>
      <div className="lined sheet tape max-w-3xl rotate-[-0.6deg] py-8 pr-6 pl-16 sm:pr-10">
        <ul className="leading-8">
          {approach.habits.map((h) => (
            <li key={h.title} className="pb-8 last:pb-0">
              <p className="font-serif text-xl leading-8">{h.title}</p>
              <p className="text-ink-2">{h.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}
