import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

const links = [
  { id: "experience", label: "Experience" },
  { id: "impact", label: "Impact" },
  { id: "approach", label: "Approach" },
  { id: "security", label: "Security" },
  { id: "projects", label: "Projects" },
  { id: "skills", label: "Skills" },
  { id: "credentials", label: "Credentials" },
  { id: "contact", label: "Contact" },
];

function currentTheme(): "light" | "dark" {
  const set = document.documentElement.dataset.theme;
  if (set === "light" || set === "dark") return set;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function Nav() {
  const [active, setActive] = useState("");
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    try {
      const saved = localStorage.getItem("theme");
      if (saved === "light" || saved === "dark") document.documentElement.dataset.theme = saved;
    } catch { /* storage unavailable */ }
    setTheme(currentTheme());

    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" },
    );
    links.forEach((l) => {
      const el = document.getElementById(l.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  const toggle = () => {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem("theme", next); } catch { /* ignore */ }
    setTheme(next);
  };

  return (
    <header className="sticky z-40 border-b border-ink/15 bg-paper/90 backdrop-blur-sm" style={{ top: "env(safe-area-inset-top, 0px)" }}>
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-4 px-4 sm:px-6">
        <a href="#top" className="hand shrink-0 !text-3xl !text-ink">
          sidhant<span className="text-red">.</span>
        </a>
        <nav aria-label="Sections" className="no-scrollbar flex min-w-0 flex-1 gap-1 overflow-x-auto">
          {links.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              className={`relative shrink-0 px-2.5 py-1.5 font-type text-sm transition-colors ${
                active === l.id ? "text-ink" : "text-ink-3 hover:text-ink"
              }`}
            >
              <span className={active === l.id ? "hl" : ""}>{l.label}</span>
            </a>
          ))}
        </nav>
        <button
          onClick={toggle}
          aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}
          title={theme === "dark" ? "Paper mode" : "Blueprint mode"}
          className="sketch grid size-9 shrink-0 place-items-center text-ink-2 hover:text-ink"
        >
          {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>
    </header>
  );
}
