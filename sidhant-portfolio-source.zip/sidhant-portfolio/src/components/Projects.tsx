import { projects } from "../data/resume";
import { Section } from "./Section";

const tilt = ["-0.8deg", "0.6deg", "0.9deg", "-0.5deg"];

export function Projects() {
  return (
    <Section id="projects" label="Side projects" title="Things I built on my own" intro="Hands-on work outside the day job, mostly from my AI/ML programme and security research.">
      <div className="grid gap-10 md:grid-cols-2">
        {projects.map((p, i) => (
          <article key={p.title} className={`sheet tape flex flex-col p-6 sm:p-8 ${i % 2 ? "tape-right" : "tape-left"}`} style={{ transform: `rotate(${tilt[i % tilt.length]})` }}>
            <div className="flex items-baseline justify-between gap-4">
              <h3 className="text-2xl">{p.title}</h3>
              <span className="tnum shrink-0 font-type text-xs text-ink-3">{p.year}</span>
            </div>
            <p className="mt-4 flex-1 text-ink-2">{p.text}</p>
            <p className="mt-6 font-type text-xs text-pen">{p.tags.map((t) => `#${t.toLowerCase().replace(/\s+/g, "-")}`).join("  ")}</p>
          </article>
        ))}
      </div>
    </Section>
  );
}
