import type { ReactNode } from "react";
import { Squiggle } from "./Doodles";

type Props = { id: string; label: string; title: ReactNode; intro?: string; note?: string; children: ReactNode };

/** A notebook "page": typewriter label, serif title with a pen underline, optional margin note. */
export function Section({ id, label, title, intro, note, children }: Props) {
  return (
    <section id={id} className="py-16 sm:py-24">
      <div className="mb-10 max-w-2xl">
        <p className="type-label mb-3">{label}</p>
        <h2 className="relative inline-block text-4xl sm:text-5xl">
          {title}
          <Squiggle className="absolute -bottom-3 left-0 h-3 w-2/3 text-pen" />
        </h2>
        {intro && <p className="mt-7 text-ink-2">{intro}</p>}
        {note && <p className="hand mt-3 -rotate-1">{note}</p>}
      </div>
      {children}
    </section>
  );
}
