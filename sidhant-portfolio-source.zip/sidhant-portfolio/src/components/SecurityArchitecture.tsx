import { useState } from "react";
import { securityFlow } from "../data/resume";
import { Section } from "./Section";

export function SecurityArchitecture() {
  const [sel, setSel] = useState("sca");
  const node = securityFlow.find((n) => n.id === sel)!;

  return (
    <Section
      id="security"
      label="Security architecture · sketch"
      title="From commit to approved release"
      intro="The build-and-scan setup I designed and administered, drawn the way I'd sketch it on a whiteboard."
      note="tap any box to zoom in"
    >
      <div className="overflow-x-auto px-1 py-3">
        <ol className="flex min-w-max items-center gap-2 lg:min-w-0">
          {securityFlow.map((n, i) => {
            const on = n.id === sel;
            return (
              <li key={n.id} className="flex items-center gap-2 lg:flex-1">
                <button
                  onClick={() => setSel(n.id)}
                  aria-pressed={on}
                  className={`sketch w-32 p-3 text-left transition-transform lg:w-full ${on ? "bg-sheet -rotate-2 scale-105" : "hover:-rotate-1"}`}
                  style={on ? { borderColor: "var(--pen)", boxShadow: "3px 3px 0 var(--pen)" } : undefined}
                >
                  <span className={`block font-type text-[11px] font-bold tracking-wider uppercase ${on ? "text-pen" : "text-ink-3"}`}>{n.stage}</span>
                  <span className="mt-1 block text-sm leading-snug">{n.title}</span>
                </button>
                {i < securityFlow.length - 1 && <span className="hand shrink-0 !text-3xl !text-ink-3">→</span>}
              </li>
            );
          })}
        </ol>
      </div>

      <div className="sheet tape tape-left mt-8 grid gap-6 p-6 sm:grid-cols-[1fr_auto] sm:p-10" aria-live="polite">
        <div>
          <p className="type-label">{node.stage}</p>
          <h3 className="mt-2 text-3xl">{node.title}</h3>
          <p className="mt-4 max-w-prose text-ink-2">{node.detail}</p>
        </div>
        <div className="flex flex-wrap content-start gap-2 sm:max-w-64 sm:justify-end">
          {node.tools.map((t) => (
            <span key={t} className="sketch-dashed px-2.5 py-1 font-type text-xs text-ink-2">{t}</span>
          ))}
        </div>
      </div>
    </Section>
  );
}
