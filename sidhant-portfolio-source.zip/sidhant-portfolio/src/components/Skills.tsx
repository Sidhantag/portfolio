import { skills } from "../data/resume";
import { Section } from "./Section";

export function Skills() {
  return (
    <Section id="skills" label="Toolbox" title="What I work with">
      <div className="grid gap-x-12 gap-y-10 md:grid-cols-2">
        {skills.map((g) => (
          <div key={g.group}>
            <p className="hand mb-3 !text-[1.9rem]">{g.group}</p>
            <div className="flex flex-wrap gap-2">
              {g.items.map((s) => (
                <span key={s} className="sketch bg-sheet px-3 py-1 text-sm">{s}</span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
