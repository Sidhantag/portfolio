// Single source of truth for all site content.
// Edit this file to update the website — components only render what is here.

export const profile = {
  name: "Sidhant Ghuge",
  fullName: "Sidhant Ashok Ghuge",
  role: "Quality Engineering & DevSecOps Leader",
  location: "Pune, Maharashtra",
  email: "saghuge@gmail.com",
  linkedin: "https://linkedin.com/in/sidhantghuge",
  linkedinLabel: "linkedin.com/in/sidhantghuge",
  // To add your photo: put a square-ish image at public/me.jpg and set photo: "me.jpg"
  photo: "" as string,
  summary:
    "8+ years in fintech, from hands-on test automation and NFR ownership to enterprise quality strategy for a multi-asset trading platform used by 50+ global financial institutions. I build the automation, security gates and observability that let teams release with evidence instead of hope. Currently upskilling in AI/ML and LLM evaluation.",
};

export const metrics = [
  { value: "5d → 8h", label: "Regression cycle", note: "1,200+ automated tests" },
  { value: "0", label: "P0 security escapes", note: "3 consecutive releases" },
  { value: "~35%", label: "Lower MTTR", note: "40+ SLO/SLI dashboards" },
  { value: "10M+", label: "CVE records triaged", note: "60% faster SLA compliance" },
  { value: "50+", label: "Institutions served", note: "APAC · EMEA · Americas" },
];

export type Role = {
  title: string;
  company: string;
  place: string;
  period: string;
  headline: string;
  points: { tag: string; text: string }[];
};

export const experience: Role[] = [
  {
    title: "Assistant Vice President – Trading Platform Automation Tools",
    company: "FinIQ Consulting Pvt. Ltd.",
    place: "Pune",
    period: "Sep 2021 – Dec 2025",
    headline:
      "Owned quality, security and observability end to end for a multi-asset trading platform (equities, derivatives, FX, bonds).",
    points: [
      { tag: "Quality", text: "Led end-to-end quality engineering for a platform serving 50+ financial institutions across APAC, EMEA and the Americas, working in Agile/Scrum with cross-functional squads." },
      { tag: "Automation", text: "Designed and maintained a Playwright/JavaScript and Selenium framework (1,200+ tests) across UI, API and integration layers; cut the regression cycle from 5 days to under 8 hours." },
      { tag: "DevSecOps", text: "Architected the DevSecOps pipeline: SAST (Fortify ScanCentral), SCA (Black Duck, Sonatype Nexus IQ) and DAST in Jenkins / Azure DevOps. Zero critical P0 security escapes for 3 consecutive release cycles." },
      { tag: "Observability", text: "Built the observability stack (Datadog, Splunk, OpenTelemetry) for Kafka-based trading pipelines; authored 40+ SLO/SLI dashboards and alert policies, reducing MTTR by ~35%." },
      { tag: "Compliance", text: "Drove ISO 27001 and PCI-DSS posture across test environments; led audit preparation and closed 18 nonconformances over two certification cycles." },
      { tag: "Tooling", text: "Engineered automated CVE triage and deduplication tooling in Python (O(n) logic) handling 10M+ records, improving remediation SLA compliance by 60%." },
      { tag: "AI Quality", text: "Designed an LLM evaluation and security research framework covering prompt injection, jailbreak vectors and model reliability." },
      { tag: "Leadership", text: "Mentored 6 SDETs and QA engineers; ran retrospectives and backlog grooming, improving team velocity by 20%." },
      { tag: "Domain", text: "Defined acceptance criteria across FIX Protocol, SWIFT messaging and structured product pricing modules to shift quality left." },
    ],
  },
  {
    title: "Application Consultant – QA Automation SME",
    company: "FinIQ Consulting Pvt. Ltd.",
    place: "Nashik",
    period: "Jun 2017 – Aug 2021",
    headline:
      "Client-facing automation SME: defined non-functional requirements and built the frameworks that made releases predictable.",
    points: [
      { tag: "NFRs", text: "Primary interface between clients and cross-functional teams, defining performance, scalability, security and resilience requirements for trading platform implementations." },
      { tag: "Automation", text: "Built and scaled frameworks with Playwright, Selenium, Java, TestNG and WebDriver, reaching 70–85% regression automation coverage." },
      { tag: "CI/CD", text: "Integrated QA into DevOps pipelines, accelerating release cycles by 30–40% and improving deployment predictability." },
      { tag: "Performance", text: "Led performance, load and stress testing (JMeter, LoadRunner): 40% higher throughput and 30% fewer production incidents." },
      { tag: "Defects", text: "Drove UAT, regression and defect triage, reducing defect leakage to production by 45–55%." },
      { tag: "Resilience", text: "Ran failover, disaster recovery and observability testing, sustaining 99.9% availability." },
      { tag: "Ownership", text: "Owned test strategy, test plans and documentation; aligned QA delivery with client commitments alongside Engineering and Project Managers." },
    ],
  },
];

export type CaseStudy = {
  id: string;
  label: string;
  title: string;
  result: string;
  context: string;
  approach: string[];
  stack: string[];
  outcome: string[];
};

// Deep-dives: problem → approach → stack → outcome. Useful as interview talking points.
export const caseStudies: CaseStudy[] = [
  {
    id: "regression",
    label: "Regression",
    title: "Cutting regression from 5 days to under 8 hours",
    result: "5 days → < 8 hours",
    context:
      "A multi-asset trading platform with client-specific configurations for 50+ institutions. Full regression was largely manual and took a working week, which capped how often we could release.",
    approach: [
      "Designed a Page Object Model framework in Playwright (JavaScript) alongside the existing Selenium suite, so UI changes are fixed in one place.",
      "Split coverage into UI, API and integration layers and moved checks down to the API layer wherever the UI added no extra confidence.",
      "Wired the suite into Jenkins / Azure DevOps so regression runs on every build instead of on request.",
      "Grew the suite to 1,200+ maintained test cases covering equities, derivatives, FX and bonds workflows.",
    ],
    stack: ["Playwright (JS)", "Selenium", "Page Object Model", "REST/SOAP API tests", "Jenkins", "Azure DevOps"],
    outcome: ["Regression cycle reduced from 5 days to under 8 hours", "Earlier role: 70–85% regression automation coverage", "Release cycles accelerated by 30–40%"],
  },
  {
    id: "devsecops",
    label: "DevSecOps",
    title: "A build-and-scan pipeline with security gates",
    result: "0 P0 escapes × 3 releases",
    context:
      "Financial clients expect vulnerabilities to be caught before release, not after. Security scanning had to become part of every build rather than a separate, late activity.",
    approach: [
      "Integrated SAST (Fortify ScanCentral), SCA (Black Duck, Sonatype Nexus IQ) and DAST (WebInspect) into Jenkins, Bitbucket Pipelines and Azure DevOps.",
      "Designed and administered the Nexus IQ Server, connected to Sonatype Data Services for real-time component governance and vulnerability intelligence.",
      "Ran a distributed scanning network: ScanCentral SAST controllers and WebInspect DAST sensors across hybrid Linux/Windows environments for concurrent scans.",
      "Enforced policy so critical findings stop a build before it reaches release.",
    ],
    stack: ["Fortify ScanCentral", "WebInspect", "Black Duck", "Sonatype Nexus IQ", "Jenkins", "Azure DevOps", "Bitbucket Pipelines"],
    outcome: ["Zero critical P0 security escapes to production for 3 consecutive release cycles", "Automated build-and-scan on CI agents"],
  },
  {
    id: "observability",
    label: "Observability",
    title: "SLO-driven observability for Kafka trading pipelines",
    result: "~35% lower MTTR",
    context:
      "Trading flows move through Kafka and messaging layers where a silent delay is as costly as an outage. Teams needed to see problems before clients reported them.",
    approach: [
      "Built the observability stack on Datadog, Splunk and OpenTelemetry across the Kafka-based pipelines.",
      "Authored 40+ SLO/SLI dashboards and alert policies tied to what the business cares about: latency, throughput and error rates.",
      "Added synthetic monitoring and log analytics so incidents could be traced from alert to root cause faster.",
    ],
    stack: ["Datadog", "Splunk", "OpenTelemetry", "Apache Kafka", "IBM MQ", "Synthetic Monitoring"],
    outcome: ["Mean time to recovery reduced by ~35%", "40+ SLO/SLI dashboards and alert policies in production use"],
  },
  {
    id: "cve",
    label: "CVE triage",
    title: "Deduplicating 10M+ vulnerability records",
    result: "60% faster SLA compliance",
    context:
      "Multiple scanners report the same vulnerability in different shapes. Teams were spending remediation time sorting duplicates instead of fixing issues.",
    approach: [
      "Wrote triage and deduplication tooling in Python using hash-map (O(n)) matching instead of pairwise comparison.",
      "Used multi-strategy matching (CVE ID, component, version) to merge findings from different scanners.",
      "Later rebuilt it as a React app with chunked async processing, SVG charts and paginated output (see Projects).",
    ],
    stack: ["Python", "pandas", "Hash-map dedup (O(n))", "React"],
    outcome: ["10M+ records processed", "Vulnerability remediation SLA compliance up 60%"],
  },
  {
    id: "compliance",
    label: "Compliance",
    title: "ISO 27001 and PCI-DSS across test environments",
    result: "18 nonconformances closed",
    context:
      "Test environments in fintech handle sensitive configurations and must meet the same controls auditors check in production.",
    approach: [
      "Drove the ISO 27001 and PCI-DSS compliance posture for test environments.",
      "Led audit preparation: evidence collection, control mapping and follow-up on findings.",
      "Tracked and closed nonconformances across two certification cycles.",
    ],
    stack: ["ISO 27001", "PCI-DSS", "Azure Key Vault", "ServiceNow", "Confluence"],
    outcome: ["18 nonconformances closed over two certification cycles"],
  },
  {
    id: "performance",
    label: "Performance",
    title: "Performance and resilience testing",
    result: "99.9% availability",
    context:
      "Trading platforms must hold up under market-open peaks and recover cleanly from failures. As QA Automation SME I owned these non-functional requirements with clients.",
    approach: [
      "Defined NFRs for performance, scalability, security and resilience with clients.",
      "Ran performance, load and stress tests with JMeter and LoadRunner.",
      "Tested failover, disaster recovery and observability to prove the platform recovers as designed.",
    ],
    stack: ["JMeter", "LoadRunner", "Failover / DR testing"],
    outcome: ["40% improvement in system throughput", "30% fewer production incidents", "99.9% availability sustained", "45–55% less defect leakage to production"],
  },
  {
    id: "llm",
    label: "LLM quality",
    title: "An evaluation and security framework for LLM features",
    result: "AI QA readiness",
    context:
      "As AI features came onto the roadmap, there was no way to test them for safety and reliability the way we tested everything else.",
    approach: [
      "Independently designed a framework to assess prompt injection, jailbreak vectors and model reliability.",
      "Continue this as independent research (2024–present) into data exfiltration and evaluation frameworks for production AI systems.",
    ],
    stack: ["LLM evaluation", "Prompt engineering", "RAG testing", "Python"],
    outcome: ["Positioned the organisation for AI feature quality assurance"],
  },
];

// "How I work" — deliberately not a schedule. Every week is different.
export const approach = {
  intro:
    "No two weeks look alike. A release week, an audit season and a quiet stretch of framework work each ask for something different. These are the things that stay the same.",
  habits: [
    { title: "Automate the repeatable", text: "Machines check what we already know. People spend their time on what's new or strange." },
    { title: "Decide on evidence", text: "A release call should rest on test results, scan policy and SLOs, not on gut feel." },
    { title: "Security belongs in the build", text: "Findings are cheapest to fix when they show up next to the code that caused them." },
    { title: "Measure what users feel", text: "Latency and errors on real trading flows say more than any server metric." },
    { title: "Leave the team stronger", text: "Mentoring, honest retros and shared ownership outlast any single release." },
  ],
};

// Security architecture nodes (left → right flow).
export const securityFlow = [
  { id: "src", stage: "Source", title: "Bitbucket", detail: "Every commit or pull request triggers a pipeline run.", tools: ["Bitbucket", "Git"] },
  { id: "ci", stage: "CI", title: "Jenkins · Azure DevOps", detail: "CI agents build the application and run the build-and-scan workflow.", tools: ["Jenkins", "Azure DevOps", "Bitbucket Pipelines"] },
  { id: "sast", stage: "SAST", title: "Fortify ScanCentral", detail: "Source code is sent to ScanCentral SAST controllers, which distribute scans across sensors on Linux and Windows.", tools: ["ScanCentral Controller", "SAST Sensors"] },
  { id: "sca", stage: "SCA", title: "Nexus IQ · Black Duck", detail: "Open-source components are checked against policy. The Nexus IQ Server pulls live vulnerability intelligence from Sonatype Data Services.", tools: ["Nexus IQ Server", "Sonatype Data Services", "Black Duck"] },
  { id: "dast", stage: "DAST", title: "WebInspect", detail: "DAST sensors scan the running application for vulnerabilities that only appear at runtime.", tools: ["WebInspect Sensors"] },
  { id: "gate", stage: "Gate", title: "Policy gate", detail: "Critical findings fail the build. Only clean builds move on to release.", tools: ["Policy rules", "Jira routing"] },
  { id: "rel", stage: "Release", title: "Nexus Repository → Azure", detail: "Approved artifacts are stored and deployed, with secrets held in Azure Key Vault.", tools: ["Nexus Repository", "Azure", "AKS", "Key Vault"] },
];

export const projects = [
  { title: "CVE Deduplication Engine", year: "2025", text: "Production-grade React app processing 10M+ records with O(n) Map-based deduplication, chunked async processing, multi-strategy matching, SVG charts and paginated output.", tags: ["React", "Algorithms", "Performance"] },
  { title: "CO2 Emission Business Case Study", year: "2025", text: "End-to-end analysis of global CO2 emission trends: a Python/pandas pipeline, statistical modelling, visual storytelling with Matplotlib/Seaborn, and business recommendations.", tags: ["Python", "pandas", "Seaborn"] },
  { title: "E-Commerce Analytics Dashboard", year: "2025", text: "Python/pandas analysis of 52K+ transactions with embedded Matplotlib charts, statistical testing (scipy) and a self-contained PDF report.", tags: ["pandas", "scipy", "Matplotlib"] },
  { title: "LLM Security Research", year: "2024 – now", text: "Independent research into prompt injection, data exfiltration, jailbreak patterns and evaluation frameworks for production AI systems.", tags: ["LLM", "Security", "Evaluation"] },
];

export const skills = [
  { group: "Quality Engineering & Automation", items: ["Selenium", "Playwright (JS)", "Pytest", "TestNG", "Page Object Model", "API Testing (REST/SOAP)", "Performance Testing", "JMeter", "LoadRunner"] },
  { group: "DevSecOps & Security", items: ["Jenkins", "Azure DevOps", "Bitbucket Pipelines", "Sonatype Nexus IQ", "Black Duck", "Fortify ScanCentral", "WebInspect (DAST)", "PCI-DSS", "ISO 27001"] },
  { group: "Observability & AIOps", items: ["Datadog", "Splunk", "OpenTelemetry", "Log Analytics", "Alert Management", "Synthetic Monitoring", "SLO/SLI Dashboards"] },
  { group: "Cloud & Infrastructure", items: ["Azure (IaaS/PaaS)", "AWS (EC2/S3/RDS)", "Docker", "Kubernetes (AKS)", "Terraform"] },
  { group: "Languages", items: ["Python", "pandas", "NumPy", "scipy", "JavaScript / Node.js", "Java", "Shell", "PowerShell", "SQL"] },
  { group: "Messaging & Trading", items: ["Apache Kafka", "IBM MQ", "FIX Protocol", "SWIFT", "Equities", "Derivatives", "FX", "Bonds"] },
  { group: "AI/ML & LLM", items: ["LLM Evaluation", "RAG Testing", "Prompt Engineering", "LLM Security", "LLMOps", "MLOps", "AI Agents", "NLP", "Computer Vision", "ML System Design"] },
  { group: "Tools & Ways of Working", items: ["Git", "Jira", "Confluence", "ServiceNow", "Azure Key Vault", "SonarQube", "Nexus Repository", "Agile/Scrum"] },
];

export const certifications = [
  { name: "AI/ML Engineering Programme", issuer: "Scaler Academy", year: "2025 – ongoing" },
  { name: "AWS Cloud Practitioner (CCP)", issuer: "Amazon Web Services", year: "2022" },
  { name: "Azure Fundamentals (AZ-900)", issuer: "Microsoft", year: "2021" },
  { name: "Certified Scrum Master (CSM)", issuer: "Scrum Alliance", year: "2020" },
  { name: "ISTQB Foundation Level (CTFL)", issuer: "ISTQB", year: "2019" },
  { name: "Black Duck SCA Practitioner", issuer: "Synopsys", year: "2019" },
  { name: "Fortify ScanCentral SAST", issuer: "HP / Micro Focus", year: "2018" },
];

export const education = {
  degree: "Bachelor of Engineering – Information Technology",
  school: "K. K. Wagh Institute of Engineering Education and Research (KKWIEER), Nashik",
  university: "Pune University",
  year: "2017",
};
