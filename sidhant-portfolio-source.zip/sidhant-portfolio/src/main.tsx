import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
// Self-hosted fonts (latin subset only) — no Google Fonts request needed
import '@fontsource/young-serif/latin-400.css'
import '@fontsource/karla/latin-400.css'
import '@fontsource/karla/latin-700.css'
import '@fontsource/karla/latin-400-italic.css'
import '@fontsource/courier-prime/latin-400.css'
import '@fontsource/courier-prime/latin-700.css'
import '@fontsource/nanum-pen-script/latin-400.css'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
